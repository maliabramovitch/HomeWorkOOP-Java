/*
* Malka Abramovitvh 314723586
* Rotem Levi 318845310
*/

import java.lang.Math;

public class Triangle1 extends AbsTriangle{
	private Point centerPoint;
	private double height;

	
	/*
	 * Default constructor	
	 */
	public Triangle1() {
		this(new Point(), Math.sqrt(3)/2);
	}
	
	
	/*
	 * Parameterized Constructor
	 */
	public Triangle1(Point centerPoint, double height) {
		if (height != 0){
			this.height = height;
			this.centerPoint = centerPoint;
		}
		else {
			this.height = Math.sqrt(3)/2;
			this.centerPoint = new Point();
		}
	}
	
	
	/*
	 * @return a copy of the center point. 
	 */
	public Point getCenter() {
		return centerPoint.copy();
	}
	
	
	/*
	 * @return the height of the triangle. 
	 */
	public double height() {
		return Math.abs(height);
	}
	
	
	/*
	 * @return the length of an edge. 
	 * This method calls a static method from HW2Utils.
	 */
	public double getLengthEdge() {
		 return Math.abs(HW2Utils.getLengthEdgeFromHeight(height));
	}
	
	
	/*
	 * @return true if the third point is positive, otherwise return false.
	 */
	public boolean isUpTriangle() {
		if (height>0) 
			return true;
		else 
			return false;
	}
	
	
	/*
	 * Move the center point of the triangle to be a copy of p. 
	 * This method doesn't change the other parameters of the triangle. If p==null, then nothing is done.
	 */
	public void setCenter(Point p) {
		if (p != null) {
			centerPoint = p.copy();
		}
	}
	
	
	/*
	 * update the height of the triangle without changing its center point, or its direction (up/down).
	 * If height <= 0, then nothing is done.
	 */
	public void updateHeight(double height) {
		if (height>0) {		
			if (this.height>0) 
				this.height = height;
			else
				this.height = -height;
		}
	}


	/*
	 * inverse the triangle, such that if the thirdVertex is upper that the others, it will be lower than them, and vice verse.
	 */
	public void inverse() {
		height *= -1;
	}
	
	
	/*
	 * update the length of edge in the triangle without changing its center point, or its direction (up/down).
	 * If lengthEdge <= 0, then nothing is done. 
	 */
	public void updateLengthEdge(double lengthEdge) {
		if (lengthEdge>0) {
			if (isUpTriangle()) 
				height = HW2Utils.getHeightFromLengthEdge(lengthEdge);
			else
				height = -HW2Utils.getHeightFromLengthEdge(lengthEdge);
		}
			
	}
	
	
	/*
	 * Multiply the edge's length of the triangle by scalePar. (the center point is * not changed). 
	 * If scalePar <= 0 then nothing is done.
	 */
	public void scale(double scalePar) {
		double edge;
		if (scalePar>0) {
			edge = getLengthEdge();
			updateLengthEdge(edge*scalePar);
		}	
	}
	
	
	/*
	 * Move up the triangle (this) by delta (Note, that delta might be
	 * negative, and then the circle is moved down).
	 * This method calls Point class's method.
	 */
	public void moveVertical(double delta) {
		centerPoint.moveVertical(delta);
	}
	
	
	/*
	 * Move the triangle (this) to the right by delta (Note, that delta
	 * might be negative, and then the circle is moved to the left).
	 * This method calls Point class's method.
	 */
	public void moveHorizontal(double delta) {
		centerPoint.moveHorizontal(delta);
	}
	
	
	/*
	 * Move the triangle (this) by delta.x horizontally, and by delta.y
	 * vertically. 
	 * If delta==null, then nothing is done.
	 * This method calls Point class's method.
	 */
	public void move(Point delta) {
		centerPoint.move(delta);
	}
	
	
	/*
	 * @return True, if the "triangle" represents the same triangle as this. 
	 * Otherwise return false. 
	 * If triangle==null, then return false. 
	 */
	public boolean isEqual(Triangle triangle) {
		return Math.abs(height) == triangle.height() && triangle.getCenter().equals(centerPoint);
	}
	
	
	/*
	 * @return the area of the triangle.
	 */
	public double getArea() {
		return (getLengthEdge()*Math.abs(height))*0.5;
	}
	
	
	/*
	 *@return the perimeter of the triangle.
	 */
	public double getPerimeter() {
		return getLengthEdge()*3;
	}
}
