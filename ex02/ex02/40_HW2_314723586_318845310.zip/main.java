import java.lang.Math;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Triangle tr1 = new Triangle1();
		Triangle tr2 = new Triangle2();

		Triangle tr3 = new Triangle1(new Point(0, (double) -1 / 3), -1);
		Triangle tr4 = new Triangle2(new Point(-1 / (Math.sqrt(3)), 0), 2 / (Math.sqrt(3)), false);
		
		Point []arr = tr2.getVertices();
		boolean b0 = tr1.contains(arr[0]);
		boolean b1 = tr1.contains(arr[1]);
		boolean b2 = tr1.contains(arr[2]);
		System.out.println(b0);
		System.out.println(b1);
		System.out.println(b2);
		System.out.println();
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		System.out.println(tr2.getCenter());
		
		System.out.println();
		
		Point []arr1 = tr1.getVertices();
		System.out.println(arr1[0]);
		System.out.println(arr1[1]);
		System.out.println(arr1[2]);
		System.out.println(tr1.getCenter());
		

		
		
	}

}
