import java.lang.Math;

public class Triangle2 extends AbsTriangle {
	private Point leftCorner;
	private double edgeLen;
	private boolean up;

	
	/*
	 * Default constructor	
	 */
	public Triangle2() {
		this(HW2Utils.getLeftPointFromCenterLengthEdge(new Point(), 1, true), 1, true);
	}

	
	/*
	 * Parameterized Constructor
	 */
	public Triangle2(Point leftCorner, double sideLen, boolean up) {
		if (sideLen != 0) {
			this.edgeLen = sideLen;
			this.leftCorner = leftCorner;
			this.up = up;
		}
		else {
			leftCorner = new Point(Math.sqrt(3) / -4, Math.sqrt(3) / -4);
			edgeLen = 1;
			up = true;
		}
	}

	
	/*
	 * @return a copy of the center point. 
	 * This method calls a static method from HW2Utils.
	 */
	public Point getCenter() {
		Point centerPoint = HW2Utils.getCenterFromLeftPointLengthEdge(leftCorner, edgeLen, up);
		return centerPoint.copy();
	}

	
	/*
	 * @return the height of the triangle. 
	 * This method calls a static method from HW2Utils.
	 */
	public double height() {
		return HW2Utils.getHeightFromLengthEdge(edgeLen);
	}

	
	/*
	 * @return the length of an edge. 
	 * This method calls a static method from HW2Utils.
	 */	
		
	public double getLengthEdge() {
		double height = height();
		return Math.abs(HW2Utils.getLengthEdgeFromHeight(height));
	}

	
	/*
	 * @return true if the third point is positive, otherwise return false.
	 */
	public boolean isUpTriangle() {
		return up;
	}

	
	/*
	 * Move the center point of the triangle to be a copy of p. 
	 * This method doesn't change the other parameters of the triangle. If p==null, then nothing is done.
	 * This method calls a static method from HW2Utils.
	 */
	public void setCenter(Point p) {
		if (p != null) {
			leftCorner = HW2Utils.getLeftPointFromCenterLengthEdge(p, edgeLen, up);
		}
	}

	
	/*
	 * update the height of the triangle without changing its center point, or its direction (up/down).
	 * If height <= 0, then nothing is done.
	 * This method calls a static method from HW2Utils.
	 */
	public void updateHeight(double height) {
		if (height > 0) {
			Point cPoint = getCenter();
			edgeLen = HW2Utils.getLengthEdgeFromHeight(Math.abs(height));
			leftCorner = HW2Utils.getLeftPointFromCenterLengthEdge(cPoint, edgeLen, up);
		}
	}

	
	/*
	 * inverse the triangle, such that if the thirdVertex is upper that the others, it will be lower than them, and vice verse.
	 * This method calls a static method from HW2Utils.
	 */
	public void inverse() {
		double height = HW2Utils.getHeightFromLengthEdge(edgeLen);
		if (up) {
			up = false;
			leftCorner.moveVertical(height);
		} else {
			up = true;
			leftCorner.moveVertical(-height);
		}
	}

	
	/*
	 * update the length of edge in the triangle without changing its center point, or its direction (up/down).
	 * If lengthEdge <= 0, then nothing is done. 
	 * This method calls a static method from HW2Utils.
	 */
	public void updateLengthEdge(double lengthEdge) {
		if (lengthEdge > 0) {
			Point cPoint = getCenter();
			edgeLen = lengthEdge;
			leftCorner = HW2Utils.getLeftPointFromCenterLengthEdge(cPoint, lengthEdge, up);
		}
	}

	
	/*
	 * Multiply the edge's length of the triangle by scalePar. (the center point is * not changed). 
	 * If scalePar <= 0 then nothing is done.
	 * This method calls a static method from HW2Utils.
	 */
	public void scale(double scalePar) {
		if (scalePar > 0) {
			updateLengthEdge(edgeLen * scalePar);
		}
	}

	
	/*
	 * Move up the triangle (this) by delta (Note, that delta might be
	 * negative, and then the circle is moved down).
	 * This method calls Point class's method.
	 */
	public void moveVertical(double delta) {
		leftCorner.moveVertical(delta);
	}

	
	/*
	 * Move the triangle (this) to the right by delta (Note, that delta
	 * might be negative, and then the circle is moved to the left).
	 * This method calls Point class's method.
	 */
	public void moveHorizontal(double delta) {
		leftCorner.moveHorizontal(delta);
	}

	
	/*
	 * Move the triangle (this) by delta.x horizontally, and by delta.y
	 * vertically. 
	 * If delta==null, then nothing is done.
	 * This method calls Point class's method.
	 */
	public void move(Point delta) {
		leftCorner.move(delta);
	}

	
	/*
	*@return True, if the "triangle" represents the same triangle as this. 
	*Otherwise return false. 
	*If triangle==null, then return false. 
	*/
	public boolean isEqual(Triangle triangle) {
		return up == triangle.isUpTriangle() && triangle.getCenter().equals(getCenter()) && edgeLen == triangle.getLengthEdge();
	}

	
	/*
	 * @return the area of the triangle.
	 */
	public double getArea() {
		return (edgeLen * height()) * 0.5;
	}

	
	/*
	 * @return the perimeter of the triangle.
	 */
	public double getPerimeter() {
		return edgeLen * 3;
	}
}
