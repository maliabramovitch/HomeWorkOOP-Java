import static org.junit.Assert.*;

import org.junit.Test;

public class Ex02Test {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
