
public abstract class AbsTriangle implements Triangle{

	/*
	 * @return an array of the three points of the circle.. 
	 * This method calls a static method from HW2Utils.
	 */
	public Point[] getVertices(){
		double height = height();
		Point centerPoint = getCenter();
		double lengthEdge = getLengthEdge();
		boolean isUp = isUpTriangle();
		Point left, topOrBottom, right;
		Point arr[] = new Point[3];
		if (isUp) {
			left = HW2Utils.getLeftPointFromCenterLengthEdge(centerPoint, lengthEdge, isUp);
			topOrBottom = new Point(left.getX()+0.5*lengthEdge, left.getY()+height);
			right = new Point(left.getX()+lengthEdge, left.getY());
		}
		else {
			left = HW2Utils.getLeftPointFromCenterLengthEdge(centerPoint, lengthEdge, isUp);
			topOrBottom = new Point(left.getX()+0.5*lengthEdge, left.getY()-height);
			right = new Point(left.getX()+lengthEdge, left.getY());
		}
		arr[2] = topOrBottom;
		arr[0] = left;
		arr[1] = right;
		return arr;
	}
	
	
	/*
	 * @return the Y value of linear equation by x value.
	 * This is a private static method. 
	 */
	private double y(double x, Point p0, Point p1) {
		double m = (p1.getY() - p0.getY()) / (p1.getX() - p0.getX());
		return m*(x - p1.getX()) + p1.getY();
	}
	
	
	/*
	 * @return True, if the triangle (this) contains the the point "p". 
	 * Otherwise return false. 
	 * If p==null, then return false.
	 */
	public boolean contains(Point p){
		boolean isUp = isUpTriangle();
		Point centerPoint = getCenter();
		Point[] arr = getVertices();
		if (isUp)
		{
			if (p.getX() == centerPoint.getX())
			{
				if (arr[2].getY() >= p.getY() && arr[1].getY() <= p.getY())
					return true;
			}
			if (p.getX() < centerPoint.getX()) 
			{
				double y = y(p.getX(), arr[2], arr[0]);
				if (y >= p.getY() && arr[1].getY() <= p.getY())
					return true;
			}
			else
			{
				double y = y(p.getX(), arr[2], arr[1]);
				if (y >= p.getY() && arr[1].getY() <= p.getY())
					return true;
			}
		}
		else
		{
			if (p.getX() == centerPoint.getX())
			{
				if (arr[2].getY() <= p.getY() && arr[0].getY() >= p.getY())
					return true;
			}
			if (p.getX() < centerPoint.getX()) 
			{
				double y = y(p.getX(), arr[0], arr[2]);
				if (y <= p.getY() && arr[0].getY() >= p.getY())
					return true;
			}
			else
			{
				double y = y(p.getX(), arr[2], arr[1]);
				if (y <= p.getY() && arr[1].getY() >= p.getY())
					return true;
			}
		}
		return false ;
	}
	
	
	/*q
	 * @return True, if the triangle (this) contains the parameter "triangle". 
	 * Otherwise return false. 
	 * If triangle==null, then return false.
	 */
	public boolean contains(Triangle tri) {
		Point[] arr2 = tri.getVertices();
		return contains(arr2[2]) && contains(arr2[0]) && contains(arr2[1]);
	}

}

