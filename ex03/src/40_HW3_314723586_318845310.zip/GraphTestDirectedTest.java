import static org.junit.Assert.*;

import org.junit.Test;

public class GraphTestDirectedTest {

	@Test
	public void testSetUp() {
		fail("Not yet implemented");
	}

	@Test
	public void testTestPutVVE() {
		fail("Not yet implemented");
	}

	@Test
	public void testTestFriendship() {
		fail("Not yet implemented");
	}

	@Test
	public void testTestSizeGraph() {
		fail("Not yet implemented");
	}

	@Test
	public void testTestAreAdjacent() {
		fail("Not yet implemented");
	}

	@Test
	public void testTestRemoveEdge() {
		fail("Not yet implemented");
	}

	@Test
	public void testTestGraph() {
		fail("Not yet implemented");
	}

	@Test
	public void testTestAddVertex() {
		fail("Not yet implemented");
	}

	@Test
	public void testTestRemoveNoEdges() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateGraph() {
		fail("Not yet implemented");
	}

	@Test
	public void testTestGet() {
		fail("Not yet implemented");
	}

	@Test
	public void testTestContainsVertex() {
		fail("Not yet implemented");
	}

	@Test
	public void testObject() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetClass() {
		fail("Not yet implemented");
	}

	@Test
	public void testHashCode() {
		fail("Not yet implemented");
	}

	@Test
	public void testEquals() {
		fail("Not yet implemented");
	}

	@Test
	public void testClone() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

	@Test
	public void testNotify() {
		fail("Not yet implemented");
	}

	@Test
	public void testNotifyAll() {
		fail("Not yet implemented");
	}

	@Test
	public void testWait() {
		fail("Not yet implemented");
	}

	@Test
	public void testWaitLong() {
		fail("Not yet implemented");
	}

	@Test
	public void testWaitLongInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testFinalize() {
		fail("Not yet implemented");
	}

}
